package up.mi.bjy.projetPOOA.CODE;

import java.util.StringTokenizer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * La classe debat. Elle represente un debat et permet de trouver les arguments
 * corrects dans un debat.
 * 
 * @author BRET David, JIANG Olivier, YE Fr�d�ric
 * Date : 16/12/2022
 * Projet : Debat_BRET_JIANG_YE
 */
public class Debat {
	/**
	 * Liste des contradicteurs d'un argument
	 */
	private ArrayList<Argument> listeContradicteur;

	/**
	 * Liste de solution
	 */
	private ArrayList<Argument> listeSolution;

	/**
	 * Liste des arguments
	 */
	private ArrayList<Argument> listeArgument;

	/**
	 * Liste des combinaisons d'argument possible
	 */
	private ArrayList<ArrayList<Argument>> listeCombinaison;

	/**
	 * Matrice d'adjacence des arguments
	 */
	private int[][] matrice;

	/**
	 * Liste des solutions preferes
	 */
	private ArrayList<String> listeSolutionPrefere;

	/**
	 * Liste des solutions admissibles
	 */
	private ArrayList<String> listeSolutionAdmissible;

	/**
	 * Solution unique afficher sur le terminal
	 */
	private String solutionFinale;

	/**
	 * Liste de chaque element d'une solution prefere
	 */
	private ArrayList<String> listeChaqueElementSolution;

	/**
	 * numero de cr�ation de l'argument
	 */
	private static int numeroArgument = 0;

	/**
	 * Scanner pour les entres clavier de l'utilisateur
	 */
	private static Scanner scanner = new Scanner(System.in);

	/**
	 * Construit un d�bat
	 */
	public Debat() {
		listeCombinaison = new ArrayList<ArrayList<Argument>>();
		listeSolution = new ArrayList<Argument>();
		listeArgument = new ArrayList<Argument>();
		listeSolutionPrefere = new ArrayList<String>();
		listeSolutionAdmissible = new ArrayList<String>();
		solutionFinale = null;
		matrice = new int[0][0];
	}

	// ------------------------------------------------------ //
	// --------------- Fonctions de recherche --------------- //
	// ------------------------------------------------------ //

	/**
	 * Verifie s'il y a une double contradiction dans la matrice
	 * 
	 * @return true si il y a une double contradiction, sinon false
	 */
	public boolean estDoubleContradictionMatrice() {
		boolean estUneDoubleContradiction = false;

		for (int i = 0; i < matrice.length; i++) {
			for (int j = 0; j < matrice.length; j++) {
				if (matrice[i][j] == 1 && matrice[j][i] == 1 && listeSolution.contains(retournerArgument(i))
						&& listeSolution.contains(retournerArgument(j))) {
					estUneDoubleContradiction = true;
					return estUneDoubleContradiction;
				}
			}
		}
		return estUneDoubleContradiction;
	}

	/**
	 * chercher un argument dans la matrice � l'aide de son num�ro de cr�ation
	 * 
	 * @param numero le numero de l'argument
	 * @return l'argument ayant le num�ro entr� en param�tre
	 */
	public Argument retournerArgument(int numero) {
		for (int i = 0; i < listeArgument.size(); i++) {
			if (listeArgument.get(i).getNumero() == numero) {
				return listeArgument.get(i);
			}
		}
		return null;
	}

	/**
	 * Cherche l'ensemble des arguments qui contredisent l'argument entre en
	 * parametre
	 * 
	 * @param argument l'argument sur lequel on cherche des possibles contradicteurs
	 * @return la liste des arguments qui contredisent l'argument en parametre
	 */
	public ArrayList<Argument> trouveContradicteur(Argument argument) {
		listeContradicteur = new ArrayList<Argument>();
		for (int i = 0; i < matrice.length; i++) {
			if (matrice[i][argument.getNumero()] == 1) {
				listeContradicteur.add(retournerArgument(i));
			}
		}
		return listeContradicteur;
	}

	/**
	 * Cherche un argument sauveur qui contredit un contradicteur qui contredit un
	 * argument
	 * 
	 * @param contradicteur le contradicteur de notre argument
	 * @return l'argument sauveur, celui qui contredit le contradicteur et donc
	 *         sauve l'argument qui etait contredit ou null
	 */
	public Argument trouveSauveur(Argument contradicteur) {
		Argument sauveur;
		if (listeSolution.contains(contradicteur))
			return null;

		for (int i = 0; i < matrice.length; i++) {
			if (matrice[i][contradicteur.getNumero()] == 1) {
				sauveur = retournerArgument(i);
				if (listeSolution.contains(sauveur))
					return sauveur;
			}
		}
		return null;
	}

	/**
	 * Verifie qu'un argument est defendu dans la liste de solution
	 * 
	 * @return true si l'ensemble des arguments de la liste de solution est defendu
	 */
	public boolean estDefendu() {
		boolean estAdmissible = true;

		for (int i = 0; i < listeSolution.size(); i++) {
			if (pasDeContradicteur(listeSolution.get(i)) == false && estAdmissible == true) {
				if (trouveContradicteur(listeSolution.get(i)) != null) {
					for (int j = 0; j < trouveContradicteur(listeSolution.get(i)).size(); j++) {
						Argument contradicteur = trouveContradicteur(listeSolution.get(i)).get(j);
						if (trouveSauveur(contradicteur) == null) {
							estAdmissible = false;
							return estAdmissible;
						}
					}
				}
			}
		}
		return estAdmissible;
	}

	/**
	 * Verifie si un argument est contredit
	 * 
	 * @param argument l'argument sur lequel on cherche des possibles contradicteurs
	 * @return true si l'argument n'est pas contredit, sinon false
	 */
	public boolean pasDeContradicteur(Argument argument) {
		boolean estSafe = true;

		for (int i = 0; i < matrice.length && estSafe; i++) {
			if (matrice[i][argument.getNumero()] != 0) {
				estSafe = false;
			}
		}
		return estSafe;
	}

	// -------------------------------------------------- //
	// ------------- Solution admissible ---------------- //
	// -------------------------------------------------- //

	/**
	 * Trouve l'ensemble des combinaisons possibles des arguments (powerset)
	 * 
	 * @param listeArgument la liste des arguments sur laquelle on veut toutes les
	 *                      combinaisons possibles
	 * @param index         indice
	 * @return la liste de toutes les combinaisons possible
	 */
	public ArrayList<ArrayList<Argument>> getToutesLesCombinaisons(ArrayList<Argument> listeArgument, int index) {
		ArrayList<ArrayList<Argument>> ToutesLesCombinaisons;
		if (index < 0) {
			ToutesLesCombinaisons = new ArrayList<ArrayList<Argument>>();
			ToutesLesCombinaisons.add(new ArrayList<Argument>());
		}

		else {
			ToutesLesCombinaisons = getToutesLesCombinaisons(listeArgument, index - 1);
			Argument item = listeArgument.get(index);
			ArrayList<ArrayList<Argument>> moreCombinaisons = new ArrayList<ArrayList<Argument>>();

			for (ArrayList<Argument> combinaison : ToutesLesCombinaisons) {
				ArrayList<Argument> newCombinaison = new ArrayList<Argument>();
				newCombinaison.addAll(combinaison);
				newCombinaison.add(item);
				moreCombinaisons.add(newCombinaison);
			}
			ToutesLesCombinaisons.addAll(moreCombinaisons);
		}
		return ToutesLesCombinaisons;
	}

	/**
	 * Convertie tous les arguments present dans listeSolution en un unique String
	 * 
	 * @return la concatenation de tout les elements de liste solution en un unique
	 *         string
	 */
	public String convertionElementListeEnString() {
		StringBuilder sBuilder = new StringBuilder();

		for (int i = 0; i < listeSolution.size(); i++) {
			sBuilder.append(listeSolution.get(i).getArgument());
			if (i < listeSolution.size() - 1)
				sBuilder.append(",");
		}
		return sBuilder.toString();
	}

	/**
	 * Ajoute un argument dans solution admissible s'il est admissible
	 */
	public void CalculSolutionAdmissible() {
		String stringTemporaire = null;
		for (int i = 0; i < listeCombinaison.size(); i++) {
			listeSolution.addAll(listeCombinaison.get(i));
			stringTemporaire = convertionElementListeEnString();
			if (estSolutionAdmissible() == true && estSolutionIdentique(stringTemporaire) == false) {
				listeSolutionAdmissible.add(stringTemporaire);
			}
			listeSolution.clear();
		}
	}

	/**
	 * Verifie si une solution est admissible
	 * 
	 * @return true si la solution est admisslbe
	 */
	public boolean estSolutionAdmissible() {
		boolean estAdmissible = true;

		if (listeSolution.isEmpty())
			return estAdmissible;
		if (estDoubleContradictionMatrice() == true || estDefendu() == false)
			estAdmissible = false;
		return estAdmissible;
	}

	/**
	 * Verifie si la solution se trouve d�j� dans la liste de solution admissible
	 * 
	 * @param solution la solution sur laquelle on cherche le doublon
	 * @return true si la solution se trouve d�j� dans la liste de solution
	 *         admissible, false sinon
	 */
	public boolean estSolutionIdentique(String solution) {
		boolean estIdentique = false;

		for (int i = 0; i < listeSolutionAdmissible.size(); i++) {
			if (solution.equals(listeSolutionAdmissible.get(i)))
				estIdentique = true;
		}
		return estIdentique;
	}

	/**
	 * Met a jour le compteur qui affiche une solution admissible
	 * 
	 * @param compteurSolutionAdmissible compteur de la solution admissible
	 * @return le compteur
	 */
	public int updateCompteurAdmissible(int compteurSolutionAdmissible) {
		compteurSolutionAdmissible++;
		if (compteurSolutionAdmissible > listeSolutionAdmissible.size() - 1)
			compteurSolutionAdmissible = 0;
		return compteurSolutionAdmissible;
	}

	/**
	 * Affiche une solution admissible
	 * 
	 * @param compteurSolutionAdmissible compteur de la solution admissible
	 */
	public void afficheUneSolutionAdmissible(int compteurSolutionAdmissible) {
		solutionFinale = listeSolutionAdmissible.get(compteurSolutionAdmissible);
		if (solutionFinale.isEmpty())
			System.out.println("vide");
		else
			System.out.println(solutionFinale);
	}

	// --------------------------------------------------- //
	// --------------- Solution pr�f�r� ------------------ //
	// --------------------------------------------------- //

	/**
	 * initialise la liste de solution prefere
	 */
	public void initialiseSolutionPrefere() {
		if (listeSolutionPrefere.isEmpty()) {
			listeSolutionPrefere = new ArrayList<String>(listeSolutionAdmissible);
			if (listeSolutionAdmissible.size() > 1)
				listeSolutionPrefere.remove(0);
		}
	}

	/**
	 * Algorithme QuickSort, trie la liste en entr�e dans l'ordre d�croissant
	 * 
	 * @param listeATrier la liste que l'on cherche � trier
	 * @param low         indice du debut
	 * @param high        indice de la fin
	 */
	public void TriRapide(ArrayList<String> listeATrier, int low, int high) {
		if (low < high) {
			int partitionIndex = partition(listeATrier, low, high);
			TriRapide(listeATrier, low, partitionIndex - 1);
			TriRapide(listeATrier, partitionIndex + 1, high);
		}
	}

	/**
	 * Le pivot de l'algorithme QuickSort R�cursivement choisi high comme pivot (le
	 * dernier element de la liste en entr�e) et change de place avec l'�lement
	 * pr�c�dent s'il est plus long que ce dernier
	 * 
	 * @param listeATrier la liste que l'on cherche � trier
	 * @param low         indice du debut
	 * @param high        indice de la fin
	 * @return indice du pivot
	 */
	public int partition(ArrayList<String> listeATrier, int low, int high) {
		String pivot = listeATrier.get(high);
		int i = (low - 1);

		for (int j = low; j <= high - 1; j++) {
			if (listeATrier.get(j).length() > pivot.length()) {
				i++;
				Collections.swap(listeATrier, i, j);
			}
		}
		Collections.swap(listeATrier, i + 1, high);
		return (i + 1);
	}

	/**
	 * Decoupe un String � chaque virgules et place ces �lements dans une liste
	 * 
	 * @param uneSolutionPrefere le String que l'on doit decompose
	 * @return une liste de tous les composants du String en param�tre
	 */
	public ArrayList<String> decomposeSolutionEnElement(String uneSolutionPrefere) {
		listeChaqueElementSolution = new ArrayList<String>();
		StringTokenizer elementDecompose = new StringTokenizer(uneSolutionPrefere, ",");

		while (elementDecompose.hasMoreTokens()) {
			String element = elementDecompose.nextToken();
			listeChaqueElementSolution.add(element);
		}
		return listeChaqueElementSolution;
	}

	/**
	 * Retire les solutions pas pr�f�r�es dans listeSolutionPrefere
	 */
	public void calculSolutionPrefere() {
		TriRapide(listeSolutionPrefere, 0, listeSolutionPrefere.size() - 1);
		for (int i = 0; i < listeSolutionPrefere.size(); i++) {
			for (int j = i + 1; j < listeSolutionPrefere.size(); j++) {
				boolean sousEnsemble = estUnSousEnsembleDe(i, j);
				if (sousEnsemble == true) {
					listeSolutionPrefere.remove(listeSolutionPrefere.get(j));
				}
			}
		}
	}

	/**
	 * retourne true si l'argument a posElementSuivant est contenu dans l'argument a
	 * posPremiereElement
	 * 
	 * @param posPremierElement indice du premier element
	 * @param posElementSuivant indice du deuxieme element
	 * @return true si l'element � posPremierElement est un sous ensemble de
	 *         l'element � posElementSuivant, false sinon
	 */
	public boolean estUnSousEnsembleDe(int posPremierElement, int posElementSuivant) {
		boolean estSousEnsemble = true;
		for (int i = 0; i < decomposeSolutionEnElement(listeSolutionPrefere.get(posElementSuivant)).size(); i++) {
			if (!listeSolutionPrefere.get(posPremierElement)
					.contains(decomposeSolutionEnElement(listeSolutionPrefere.get(posElementSuivant)).get(i))) {
				estSousEnsemble = false;
			}
		}
		return estSousEnsemble;
	}

	/**
	 * Met a jour le compteur qui affiche une solution pr�f�r�e
	 * 
	 * @param compteurSolutionPrefere compteur de la solution pr�f�r�e
	 * @return le compteur mise � jour
	 */
	public int updateCompteurPrefere(int compteurSolutionPrefere) {
		compteurSolutionPrefere++;
		if (compteurSolutionPrefere > listeSolutionPrefere.size() - 1)
			compteurSolutionPrefere = 0;
		return compteurSolutionPrefere;
	}

	/**
	 * Affiche une solution pr�f�r�e
	 * 
	 * @param compteurSolutionPrefere compteur de la solution pr�f�r�e
	 */
	public void afficheUneSolutionPrefere(int compteurSolutionPrefere) {
		solutionFinale = listeSolutionPrefere.get(compteurSolutionPrefere);
		System.out.println(solutionFinale);
	}

	// -------------------------------------------------- //
	// --------------- Fonctions du menu ---------------- //
	// -------------------------------------------------- //

	/**
	 * Affiche le menu graphique
	 * 
	 * @throws FileNotFoundException Erreur Sauvegarde : Fichier inexistant
	 * @throws IOException           Erreur Sauvegarde : Fichier inexistant
	 */
	public void menu() throws FileNotFoundException, IOException {
		String choix;
		Boolean aTrouveSolution = false;
		int compteurSolutionAdmissible = 0;
		int compteurSolutionPrefere = 0;

		// Le calcul se fait en amont pour pouvoir cqlculer et afficher une solution
		// pr�f�r�e sans devoir calculer une solution admissible au pr�alable
		listeCombinaison = getToutesLesCombinaisons(listeArgument, listeArgument.size() - 1);
		CalculSolutionAdmissible();
		initialiseSolutionPrefere();
		calculSolutionPrefere();

		while (true) {
			System.out.println("\n1. Chercher une solution admissible");
			System.out.println("2. Chercher une solution pr�f�r�e");
			System.out.println("3. Sauvegarder la solution");
			System.out.println("4. Fin\n");
			System.out.print("Votre choix : ");
			choix = scanner.nextLine();

			if (choix.equals("4")) {
				System.out.println("\nAu revoir !");
				break;
			}
			
			switch (choix) {
			case "1":
				aTrouveSolution = true;
				afficheUneSolutionAdmissible(compteurSolutionAdmissible);
				compteurSolutionAdmissible = updateCompteurAdmissible(compteurSolutionAdmissible);
				break;

			case "2":
				aTrouveSolution = true;
				afficheUneSolutionPrefere(compteurSolutionPrefere);
				compteurSolutionPrefere = updateCompteurPrefere(compteurSolutionPrefere);
				break;

			case "3":
				sauvegardeSolution(aTrouveSolution);
				break;

			default:
				System.out.println("Choix incorrect : " + choix + " est invalide.");
			}
		}
		scanner.close();
		System.exit(0);
	}

	// ----------------------------------------------------------------- //
	// ---------- Fonctions de lecture/sauvegarde par fichier ---------- //
	// ----------------------------------------------------------------- //

	/**
	 * Affiche une erreur si un argument poss�de un nom interdit
	 * 
	 * @param nomArgument le nom de l'argument dans le fichier source
	 * @param numeroLigne le num�ro de la ligne lu
	 */
	public void verifieNomArgumentInterdit(String nomArgument, int numeroLigne) {
		if (nomArgument.isEmpty()) {
			System.out.println("Erreur d'initialisation (ligne " + numeroLigne + "): argument est vide.");
			System.exit(0);
		}
		if (nomArgument.equals("argument") || nomArgument.equals("Argument") || nomArgument.equals("ARGUMENT")) {
			System.out.println("Erreur d'initialisation (ligne " + numeroLigne + "): argument est un nom interdit.");
			System.exit(0);
		}
		if (nomArgument.equals("contradiction") || nomArgument.equals("Contradiction")
				|| nomArgument.equals("CONTRADICTION")) {
			System.out
					.println("Erreur d'initialisation (ligne " + numeroLigne + "): contradiction est un nom interdit.");
			System.exit(0);
		}
		if (nomArgument.equals(",")) {
			System.out.println("Erreur d'initialisation (ligne " + numeroLigne + "): , est un nom interdit.");
			System.exit(0);
		}
		if (nomArgument.equals("(") || nomArgument.contains(")")) {
			System.out.println("Erreur d'initialisation (ligne " + numeroLigne + "): ( et ) sont des noms interdits.");
			System.exit(0);
		}
		if (nomArgument.equals(",")) {
			System.out.println("Erreur d'initialisation (ligne " + numeroLigne + "): , est un nom interdit.");
			System.exit(0);
		}
	}

	/**
	 * retourne vrai si le String en parametre commence par a ou A
	 * 
	 * @param ligne une ligne du fichier
	 * @return true ou false
	 */
	public boolean siCommenceParArgument(String ligne) {
		if (ligne.startsWith("a") || ligne.startsWith("A"))
			return true;
		return false;
	}

	/**
	 * retourne vrai si le String en parametre commence par c ou C
	 * 
	 * @param ligne une ligne du fichier
	 * @return true ou false
	 */
	public boolean siCommenceParContradiction(String ligne) {
		if (ligne.startsWith("c") || ligne.startsWith("C"))
			return true;
		return false;
	}

	/**
	 * Affiche une erreur si argument � �t� mal �crit
	 * 
	 * @param ligne       une ligne du fichier
	 * @param numeroLigne le num�ro de la ligne lu
	 */
	public void verifieSiLigneArgumentCorrecte(String ligne, int numeroLigne) {
		String syntaxe = null;
		syntaxe = ligne.substring(0, ligne.indexOf("("));

		if (!syntaxe.equals("argument") && !syntaxe.equals("Argument") && !syntaxe.equals("ARGUMENT")) {
			System.out.println(
					"Erreur d'initialisation (ligne " + numeroLigne + "): argument a �t� mal �crit -> " + syntaxe);
			System.exit(0);
		}
		seTermineParUnPoint(ligne, numeroLigne);
	}

	/**
	 * Affiche une erreur si le String en parmetre ne se termine pas par un point
	 * 
	 * @param ligne       une ligne du fichier
	 * @param numeroLigne le num�ro de la ligne lu
	 */
	public void seTermineParUnPoint(String ligne, int numeroLigne) {
		if (!ligne.endsWith(".")) {
			System.out.println(
					"Erreur d'initialisation (ligne " + numeroLigne + "): la ligne doit se terminer par un point.");
			System.exit(0);
		}
	}

	/**
	 * Affiche une erreur si contradiction � �t� mal �crit
	 * 
	 * @param ligne       une ligne du fichier
	 * @param numeroLigne le num�ro de la ligne lu
	 */
	public void verifieSiLigneContradictionCorrecte(String ligne, int numeroLigne) {
		String syntaxe = null;
		syntaxe = ligne.substring(0, ligne.indexOf("("));

		if (!syntaxe.equals("contradiction") && !syntaxe.equals("Contradiction") && !syntaxe.equals("CONTRADICTION")) {
			System.out.println(
					"Erreur d'initialisation (ligne " + numeroLigne + "): contradiction a �t� mal �crit -> " + syntaxe);
			System.exit(0);
		}
		seTermineParUnPoint(ligne, numeroLigne);
	}

	/**
	 * Affiche une erreur si un argument � �t� plac� apr�s une contradiction
	 * 
	 * @param ligne          une ligne du fichier
	 * @param numeroLigne    le num�ro de la ligne lu
	 * @param noMoreArgument un booleen qui indique si une contradiction � �t� lu
	 * 
	 */
	public void verifieSiArgumentApresContradiction(String ligne, int numeroLigne, boolean noMoreArgument) {
		if (noMoreArgument) {
			System.out.println("Erreur d'initialisation (ligne " + numeroLigne
					+ "): Un argument � �t� plac� apr�s une contradiction");
			System.exit(0);
		}
	}

	/**
	 * Initialise les argumets et les contradictions en appellant les methodes
	 * initialiseArgument() et initialiseContradiction()
	 * 
	 * @throws IOException           Erreur Initialisation : Fichier non trouve
	 * @throws FileNotFoundException Erreur Initialisation : Input incorrect
	 * @throws NullPointerException  Erreur Initialisation : nom de contradiction
	 *                               incorrect
	 */
	public void initialiseViaFichier() throws FileNotFoundException, IOException, NullPointerException {
		initialiseArgument();
		initialiseContradiction();
	}

	/**
	 * Lit dans le fichier source et initialise les arguments dans une liste
	 * d'arguments
	 * 
	 * @throws IOException           Erreur Initialisation : Fichier non trouve
	 * @throws FileNotFoundException Erreur Initialisation : chemin du fichier
	 *                               incorrect
	 */
	public void initialiseArgument() throws IOException, FileNotFoundException {
		String ligne = null;
		String ligneSansEspace = null;
		String contenu = null;
		int numeroLigne = 0;
		Boolean noMoreArgument = false;

		try {
			String path = Main.getChemin();
			File fichierInput = new File(path);
			BufferedReader br = new BufferedReader(new FileReader(fichierInput));

			while ((ligne = br.readLine()) != null) {
				ligneSansEspace = ligne.replaceAll("\\s", "");
				numeroLigne++;

				if (siCommenceParContradiction(ligneSansEspace))
					noMoreArgument = true;
				if (siCommenceParArgument(ligneSansEspace)) {
					verifieSiLigneArgumentCorrecte(ligneSansEspace, numeroLigne);
					verifieSiArgumentApresContradiction(ligneSansEspace, numeroLigne, noMoreArgument);

					contenu = ligneSansEspace.substring(ligneSansEspace.indexOf("(") + 1,
							ligneSansEspace.lastIndexOf(")"));
					verifieNomArgumentInterdit(contenu, numeroLigne);

					Argument argument = new Argument(contenu, numeroArgument);
					listeArgument.add(argument);
					numeroArgument++;
				}
			}
			br.close();

		} catch (FileNotFoundException e) {
			System.out.println("Erreur Initialisation : Fichier non trouve.");
		} catch (IOException e) {
			System.out.println("Erreur Initialisation : chemin du fichier incorrect.");
		}
	}

	/**
	 * Lit dans le fichier source et initialise les contradictions dans la matrice
	 * d'adjacence
	 * 
	 * @throws IOException           Erreur Initialisation : Fichier non trouve
	 * @throws FileNotFoundException Erreur Initialisation : Input incorrect
	 * @throws NullPointerException  Erreur Initialisation : nom de contradiction
	 *                               incorrect
	 */
	public void initialiseContradiction() throws IOException, FileNotFoundException, NullPointerException {
		String ligne = null;
		String ligneSansEspace = null;
		String contenu1 = null;
		String contenu2 = null;
		Boolean estInitialise = false;
		int numeroLigne = 0;

		try {
			String path = Main.getChemin();
			File fichierInput = new File(path);
			BufferedReader br = new BufferedReader(new FileReader(fichierInput));

			while ((ligne = br.readLine()) != null) {
				ligneSansEspace = ligne.replaceAll("\\s", "");
				numeroLigne++;

				if (siCommenceParContradiction(ligneSansEspace)) {
					verifieSiLigneContradictionCorrecte(ligneSansEspace, numeroLigne);

					if (!estInitialise) {
						this.matrice = initialiseMatrice();
						estInitialise = true;
					}

					contenu1 = ligneSansEspace.substring(ligneSansEspace.indexOf("(") + 1,
							ligneSansEspace.indexOf(","));
					contenu2 = ligneSansEspace.substring(ligneSansEspace.indexOf(",") + 1,
							ligneSansEspace.lastIndexOf(")"));

					Argument argument1 = chercherDansListeArgument(contenu1);
					Argument argument2 = chercherDansListeArgument(contenu2);
					this.matrice[argument1.getNumero()][argument2.getNumero()] = 1;
				}

			}
			br.close();
			System.out.println("Fichier inisialis� avec succ�s.");

		} catch (FileNotFoundException e) {
			System.out.println("Erreur Initialisation : Fichier non trouve.");
		} catch (IOException e) {
			System.out.println("Erreur Initialisation : Input incorrect.");
		} catch (NullPointerException e) {
			System.out
					.println("Erreur Initialisation (ligne " + numeroLigne + "): Nom incorrect dans la contradiction");
			System.exit(0);
		}
	}

	/**
	 * Initialise la matrice � 0
	 * 
	 * @return la matrice initialis�e � 0
	 */
	public int[][] initialiseMatrice() {
		matrice = new int[listeArgument.size()][listeArgument.size()];
		for (int i = 0; i < listeArgument.size(); i++) {
			for (int j = 0; j < listeArgument.size(); j++) {
				matrice[i][j] = 0;
			}
		}
		return matrice;
	}

	/**
	 * Cherche un argument dans la liste argument
	 * 
	 * @param argumentATrouver l'argument � trouver
	 * @return l'argument trouv� s'il existe
	 */
	public Argument chercherDansListeArgument(String argumentATrouver) {
		for (int i = 0; i < listeArgument.size(); i++) {
			if (listeArgument.get(i).getArgument().equals(argumentATrouver))
				return listeArgument.get(i);
		}
		return null;
	}

	/**
	 * Sauvegarde la derni�re solution obtenue dans un fichier "Sauvegarde.txt" �
	 * l'emplacement selectionn� par l'utilisateur
	 * 
	 * @param aTrouveSolution boolean qui eviter de sauvegarder sans avoir trouve
	 *                        une solution au prealable
	 * @throws IOException           Erreur Sauvegarde : Fichier inexistant
	 * @throws FileNotFoundException Erreur Sauvegarde : Chemin de sauvegarde
	 *                               incorrect
	 */
	public void sauvegardeSolution(boolean aTrouveSolution) throws IOException, FileNotFoundException {
		String path = null;

		if (!aTrouveSolution) {
			System.out.println(
					"Erreur Sauvegarde : Vous devez choisir l'option 1 ou 2 au moins une fois avant de sauvegarder.");
			return;
		}

		System.out.println("Chemin o� sauvegarder votre fichier : ");
		System.out.println("(Par default privilegiez 'src/up/mi/bjy/projetPOOA/DATABASE/')");
		path = scanner.nextLine();

		try {
			File fichierSauvegarde = new File(path + "/Sauvegarde.txt");
			PrintWriter pw = new PrintWriter(fichierSauvegarde);

			if (!fichierSauvegarde.exists())
				fichierSauvegarde.createNewFile();

			pw.println("Sauvegarde des solutions obtenues\n");
			pw.print(solutionFinale);
			pw.close();
			System.out.println("Fichier sauvegard� avec succ�s.");

		} catch (FileNotFoundException e) {
			System.out.println("Erreur Sauvegarde : Chemin de sauvegarde incorrect.");
		} catch (IOException e) {
			System.out.println("Erreur Sauvegarde : Fichier inexistant.");
		}
	}
}