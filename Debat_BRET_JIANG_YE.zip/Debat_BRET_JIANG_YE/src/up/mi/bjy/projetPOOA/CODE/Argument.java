package up.mi.bjy.projetPOOA.CODE;

/**
 * La classe Argument
 * Elle represente un argument
 * 
 * @author BRET David, JIANG Olivier, YE Fr�d�ric
 * Date : 16/12/2022
 * Projet : Debat_BRET_JIANG_YE
 */
public class Argument {
	/**
	 * nom de l'argument
	 */
	private String argument;
	
	/**
	 * numero de cr�ation de l'argument
	 */
	private int numero;

	/** 
	*  Construit un argument avec un nom et un num�ro de cr�ation
	*  
	* @param nomArgument le nom de l'argument et numero le numero de l'argument
	* @param numeroCreation le num�ro de cr�ation de l'argument
	*/
	public Argument(String nomArgument, int numeroCreation) {
		this.argument = nomArgument;
		this.numero = numeroCreation;
	}

	/**
	* Permet d'obtenir le nom de l'argument
	* 
	* @return le nom de l'argument
	*/
	public String getArgument() {
		return argument;
	}

	/**
	* Permet d'obtenir le numero de l'argument
	* 
	* @return le numero de cr�ation de l'argument
	*/
	public int getNumero() {
		return numero;
	}
	
	/**
	* Permet de modifier le numero de l'argument avec un int entr� en param�tre
	* 
	* @param nouveauNumero le num�ro de cr�ation de l'argument modifi�
	*/
	public void setNumero(int nouveauNumero) {
		this.numero = nouveauNumero;
	}

}
