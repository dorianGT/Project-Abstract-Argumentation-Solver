package up.mi.bjy.projetPOOA.CODE;

import java.io.IOException;

/**
 * Classe principale de notre application
 * 
 * @author BRET David, JIANG Olivier, YE Fr�d�ric
 * Date : 16/12/2022
 * Projet : Debat_BRET_JIANG_YE
 */
public class Main {
	/**
	 * Le chemin du fichier qui contient les arguments et contradictions du debat
	 */
	private static String chemin;

	/**
	 * Permet de retourner le chemin en argument
	 * @return le chemin en argument
	 */
	public static String getChemin() {
		return chemin;
	}

	/**
	 * Methode main permettant de lancer le debat
	 * 
	 * @param args les arguments de la classe main, ici contient le chemin du
	 *             fichier qui contient les arguments et contradictions
	 * @throws IOException Erreur Sauvegarde : Fichier inexistant
	 */
	public static void main(String[] args) throws IOException {
		chemin = args[0];
		Debat debat = new Debat();

		debat.initialiseViaFichier();
		debat.menu();
	}
}
