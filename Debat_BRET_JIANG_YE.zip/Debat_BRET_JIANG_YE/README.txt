0. Documentation Java dans doc > index.html

1. Placez le fichier avec les arguments/contradictions dans "src/up/mi/bjy/projetPOOA/DATABASE/".
2. Ecrivez le path du fichier dans Main.java > Run as > Run Configuration > Argument.
   (exemple avec Debat.txt : "src/up/mi/bjy/projetPOOA/DATABASE/Debat.txt")
3. Sauvegardez dans "src/up/mi/bjy/projetPOOA/DATABASE/" de preference.
4. F5 pour mettre a jour Eclipse et voir les changements.